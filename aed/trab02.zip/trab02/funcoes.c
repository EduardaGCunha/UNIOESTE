#include "funcoes.h"
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// Escreve o cabeçalho no arquivo
void escreve_cabecalho(FILE* arq, cabecalho* cab) {
    fseek(arq, 0, SEEK_SET);
    fwrite(cab, sizeof(cabecalho), 1, arq);
}

// Lê o cabeçalho do arquivo
cabecalho* le_cabecalho(FILE* arq) {
    cabecalho * cab = (cabecalho*) malloc(sizeof(cabecalho));
    fseek(arq, 0, SEEK_SET);
    fread(cab, sizeof(cabecalho), 1, arq);
    return cab;
}

// Cria uma árvore binária vazia no arquivo
void cria_arvore_vazia(FILE* arq) {
    cabecalho * cab = (cabecalho*) malloc(sizeof(cabecalho));
    cab->pos_cabeca = -1;
    cab->pos_topo = 0;
    cab->pos_livre = -1;
    escreve_cabecalho(arq, cab);
    free(cab);
}

// Escreve um nó na posição específica
void escreve_no(FILE* arq, no* x, int pos) {
    fseek(arq, sizeof(cabecalho) + pos * sizeof(no), SEEK_SET);
    fwrite(x, sizeof(no), 1, arq);
}

// Lê um nó do arquivo em uma posição específica
no* le_no(FILE* arq, int pos) {
    no* x = malloc(sizeof(no));
    fseek(arq, sizeof(cabecalho) + pos * sizeof(no), SEEK_SET);
    fread(x, sizeof(no), 1, arq);
    return x;
}

// Insere um novo nó na árvore binária
void insere_arvore(FILE* arq, LIVRO info) {
    cabecalho* cab = le_cabecalho(arq);
    no* novo_no = malloc(sizeof(no));
    novo_no->livro = info;
    novo_no->esq = -1;
    novo_no->dir = -1;

    int pos_atual = cab->pos_cabeca;
    int pos_anterior = -1;
    int direcao = 0; // 0 -> root, -1 -> esq, 1 -> dir

    while (pos_atual != -1) {
        pos_anterior = pos_atual;
        //printf("pos anterior: %d pos_atual %d\n", pos_anterior, pos_atual);
        no* atual = le_no(arq, pos_atual);

        if (info.codigo < atual->livro.codigo) {
            pos_atual = atual->esq;
            direcao = -1;
        } else {
            pos_atual = atual->dir;
            direcao = 1;
        }
        free(atual);
    }

    if (cab->pos_livre == -1) {
        escreve_no(arq, novo_no, cab->pos_topo);
        if (pos_anterior == -1) {
            cab->pos_cabeca = cab->pos_topo;
        } else {
            no* pai = le_no(arq, pos_anterior);
            if (direcao == -1) pai->esq = cab->pos_topo;
            else pai->dir = cab->pos_topo;
            escreve_no(arq, pai, pos_anterior);
            free(pai);
        }
        cab->pos_topo++;
    } else {
        int pos_livre = cab->pos_livre;
        no* livre = le_no(arq, pos_livre);
        cab->pos_livre = livre->dir;
        escreve_no(arq, novo_no, pos_livre);
        if (pos_anterior == -1) {
            cab->pos_cabeca = pos_livre;
        } else {
            no* pai = le_no(arq, pos_anterior);
            if (direcao == -1) pai->esq = pos_livre;
            else pai->dir = pos_livre;
            escreve_no(arq, pai, pos_anterior);
            free(pai);
        }
        free(livre);
    }

    escreve_cabecalho(arq, cab);
    free(cab);
    free(novo_no);
}

// Função auxiliar para buscar o menor elemento de uma subárvore
#include <stdio.h>
#include <stdlib.h>

// Função auxiliar para encontrar o maior nó na subárvore esquerda
int busca_maior(FILE* arq, int posicao) {
    no* atual = le_no(arq, posicao);
    int pos_pai = posicao; // Armazena a posição do pai do maior nó

    // Encontra o maior elemento na subárvore (mais à direita)
    while (atual->dir != -1) {
        pos_pai = posicao;
        posicao = atual->dir;
        free(atual);
        atual = le_no(arq, posicao);
    }

    int codigo_maior = atual->livro.codigo;

    // Se o maior nó tiver um filho à esquerda, ele substitui o maior nó
    if(atual->esq == -1 && atual->dir == -1){
        no* pai_maior = le_no(arq, pos_pai);
        pai_maior->dir = -1;
        escreve_no(arq, pai_maior, pos_pai);
        free(pai_maior);
    }
    else if (atual->esq != -1) {
        no* pai_maior = le_no(arq, pos_pai);
            pai_maior->dir = atual->esq;
        escreve_no(arq, pai_maior, pos_pai);
        free(pai_maior);
    }
    //TALVEZ NAO ESTEJA RETORNANDO A POSICAO CERTA
    free(atual);
    return posicao;
}

// Função principal de remoção
void remove_arvore(FILE* arq) {
    int codigo;
    printf("\nDigite o código do livro a ser removido\n");
    scanf("%d", &codigo);
    cabecalho* cab = le_cabecalho(arq);
    if (cab->pos_cabeca == -1) {
        printf("Árvore vazia.\n");
        free(cab);
        return;
    }
    int pos_atual = cab->pos_cabeca, pos_pai = -1;
    int direcao = 0; // Direção: -1 para esquerda, 1 para direita

    while (pos_atual != -1) {
        no* atual = le_no(arq, pos_atual);

        //printf("posatual: %d cod: %d dir: %d esq: %d\n", pos_atual, atual->livro.codigo, atual->dir, atual->esq);

        if (codigo == atual->livro.codigo) {
            int pos_remocao = pos_atual;

            // Caso 1: Nó folha
            if (atual->esq == -1 && atual->dir == -1) {
                if (pos_pai == -1) {  // É a raiz
                    cab->pos_cabeca = -1;
                    //vazando memoria, se der algo errado talvez seja isso?
                } else {
                    no* pai = le_no(arq, pos_pai);
                    if (direcao == -1) pai->esq = -1;
                    else pai->dir = -1;
                    escreve_no(arq, pai, pos_pai);
                    free(pai);
                }
            }
            // Caso 2: Nó com um único filho
            else if (atual->esq == -1 || atual->dir == -1) {
                int filho = (atual->esq != -1) ? atual->esq : atual->dir;

                if (pos_pai == -1) {  // É a raiz
                    cab->pos_cabeca = filho;
                } else {
                    no* pai = le_no(arq, pos_pai);
                    if (direcao == -1) pai->esq = filho;
                    else pai->dir = filho;
                    escreve_no(arq, pai, pos_pai);
                    free(pai);
                }
            }
            // Caso 3: Nó com dois filhos
            else {
                // Substituir pelo maior elemento da subárvore esquerda
                int posicao = busca_maior(arq, atual->esq);
                no *novaraiz = le_no(arq, posicao);
                
                if(atual->esq != posicao) novaraiz->esq = atual->esq;
                if(atual->dir != posicao) novaraiz->dir = atual->dir;

                escreve_no(arq, novaraiz, posicao);
                //se for raiz, setar nova raiz
                if (pos_pai == -1) {
                    cab->pos_cabeca = posicao;
                }else{
                    no* pai = le_no(arq, pos_pai);
                    if (direcao == -1) pai->esq = posicao;
                    else pai->dir = posicao;
                    escreve_no(arq, pai, pos_pai);
                    free(pai);
                }
                //atual->livro.codigo = -1; 
                //printf("cod: %d esq: %d dir: %d", novaraiz)

                //reescrevendo o atual para setar ele como -1 
                //escreve_no(arq, atual, pos_atual);
                //printf("%d %d\n", pos_atual, pos_pai);
                // Agora, o maior nó precisa ser removido da subárvore esquerda
                // pos_pai = pos_atual;
                // pos_atual = atual->esq;
                // codigo = posicao;
            }


            // Atualiza a lista de posições livres
            atual->dir = cab->pos_livre;
            atual->esq = -1;
            cab->pos_livre = pos_remocao;
            //falando q atual se conecta com o primeiro da lista de removidos
            escreve_no(arq, atual, pos_remocao);
            escreve_cabecalho(arq, cab);
            free(atual);
            printf("Livro excluído com sucesso!\n");
            break;
        }

        // Atualiza para o próximo nó
        pos_pai = pos_atual;
        direcao = (codigo < atual->livro.codigo) ? -1 : 1;
        pos_atual = (codigo < atual->livro.codigo) ? atual->esq : atual->dir;
        free(atual);
    }

    if (pos_atual == -1) {
        printf("Livro não encontrado.\n");
    }

    free(cab);
}


char* trim(char* str) {
    char *end;

    // Remove espaços do início
    while(isspace((unsigned char)*str)) str++;
    // Se a string for toda de espaços
    if(*str == 0)
        return str;
    // Remove espaços do final
    end = str + strlen(str) - 1;
    while(end > str && isspace((unsigned char)*end)) end--;
    // Coloca o caractere de fim de string
    *(end + 1) = '\0';
    return str;
}

void ler(LIVRO *l){
    printf("Digite o código, título, autor, editora, edição, ano, preço e estoque nessa ordem\n");
    scanf("%d%*c", &l->codigo);
    scanf("%150[^\n]%*c", l->titulo);  // Lê até 150 caracteres ou até nova linha
    scanf("%200[^\n]%*c", l->autor);   // Lê até 200 caracteres ou até nova linha
    scanf("%50[^\n]%*c", l->editora);
    scanf("%d%*c", &l->edicao);
    scanf("%d", &l->ano);
    scanf("%lf", &l->preco);
    scanf("%d", &l->estoque);
}

void imprimir_livro(FILE* file) {
    cabecalho* cab = le_cabecalho(file);
    int codigo;

    printf("\nDigite o código do livro a ser impresso\n");
    scanf("%d", &codigo);

    int pos_aux = cab->pos_cabeca; // Em uma árvore, começamos pela raiz
    no* aux = NULL;

    // Realiza a busca binária na árvore pelos nós da estrutura
    while (pos_aux != -1) {
        aux = le_no(file, pos_aux);

        if (aux->livro.codigo == codigo) {
            // Imprime os detalhes do livro se encontrado
            printf("\n Título: %s", aux->livro.titulo);
            printf("\n Autor: %s", aux->livro.autor);
            printf("\n Editora: %s", aux->livro.editora);
            printf("\n Edição: %d", aux->livro.edicao);
            printf("\n Código: %d\n", aux->livro.codigo);
            break;
        } else if (codigo < aux->livro.codigo) {
            pos_aux = aux->esq;  // Vai para o filho à esquerda
        } else {
            pos_aux = aux->dir;  // Vai para o filho à direita
        }

        free(aux); // Libera o nó após leitura para evitar vazamento de memória
    }

    if (pos_aux == -1) {
        printf("\nLivro com código %d não encontrado.\n", codigo);
    }
    free(cab);  // Libera a memória alocada para o cabeçalho
}

void listar_em_ordem(FILE* file, int pos_atual) {
    if (pos_atual == -1) {
        return;  // Base da recursão, retorna quando o nó é inválido
    }

    no* aux = le_no(file, pos_atual);

    // Percorre o filho esquerdo
    listar_em_ordem(file, aux->esq);

    // Imprime apenas o código e o título do livro no nó atual
    printf("Código: %d | Título: %s\n", aux->livro.codigo, aux->livro.titulo);

    // Percorre o filho direito
    listar_em_ordem(file, aux->dir);

    free(aux);  // Libera a memória do nó atual após o uso
}

void listar(FILE* file) {
    cabecalho* cab = le_cabecalho(file);

    if (cab->pos_cabeca == -1) {
        printf("Ainda não há livros cadastrados!\n");
        free(cab);
        return;
    }

    printf("---------------LIVROS CADASTRADOS--------------\n");
    listar_em_ordem(file, cab->pos_cabeca);  // Chama a função auxiliar para percorrer a árvore

    free(cab);  // Libera a memória do cabeçalho após o uso
}

void busca_por_autor_aux(FILE* file, int pos_atual, const char* nome, int* encontrou) {
    if (pos_atual == -1) {
        return;  // Base da recursão: nó inválido
    }

    no* aux = le_no(file, pos_atual);

    // Percorre o filho esquerdo
    busca_por_autor_aux(file, aux->esq, nome, encontrou);

    // Verifica se o autor do livro no nó atual corresponde ao nome buscado
    if (strcmp(aux->livro.autor, nome) == 0) {
        printf("- %s\n", aux->livro.titulo);
        *encontrou = 1;
    }

    // Percorre o filho direito
    busca_por_autor_aux(file, aux->dir, nome, encontrou);

    free(aux);  // Libera a memória do nó após o uso
}

void busca_por_autor(FILE* file) {
    char nome[201];
    cabecalho* cab = le_cabecalho(file);
    int encontrou = 0;

    printf("Digite o nome do autor a ser buscado\n");
    scanf("%[^\n]%*c", nome);
    nome[strcspn(nome, "\n")] = '\0';
    printf("\nLivros do Autor: %s\n", nome);

    busca_por_autor_aux(file, cab->pos_cabeca, nome, &encontrou);

    if (!encontrou) {
        printf("Nenhum livro encontrado para o autor: %s\n", nome);
    }

    free(cab);  // Libera o cabeçalho após o uso
}

void busca_por_titulo_aux(FILE* file, int pos_atual, const char* titulo, int* encontrado) {
    if (pos_atual == -1) {
        return;
    }

    no* aux = le_no(file, pos_atual);
    busca_por_titulo_aux(file, aux->esq, titulo, encontrado);
    if (strcmp(aux->livro.titulo, titulo) == 0) {
        printf("\nInformações do livro %s\n", titulo);
        printf("%s\n", aux->livro.titulo);
        printf("Código: %d\n", aux->livro.codigo);
        printf("Edicao: %d\n", aux->livro.edicao);
        printf("Autor: %s\n", aux->livro.autor);
        printf("Editora: %s\n", aux->livro.editora);
        printf("Ano: %d\n", aux->livro.ano);
        printf("Preço: R$ %.2lf\n", aux->livro.preco);
        printf("Estoque: %d\n", aux->livro.estoque);
        *encontrado = 1;
    }
    busca_por_titulo_aux(file, aux->dir, titulo, encontrado);

    free(aux);
}

void busca_por_titulo(FILE* file) {
    char titulo[201];
    cabecalho* cab = le_cabecalho(file);
    int encontrado = 0;

    printf("Digite o título do livro a ser buscado\n");
    scanf("%[^\n]%*c", titulo);
    titulo[strcspn(titulo, "\n")] = '\0';

    busca_por_titulo_aux(file, cab->pos_cabeca, titulo, &encontrado);

    if (!encontrado) {
        printf("Nenhum livro com esse título encontrado\n");
    }

    free(cab);  // Libera o cabeçalho após o uso
}

int calcular_total_aux(FILE* file, int pos_atual) {
    if (pos_atual == -1) {
        return 0;  // Base da recursão
    }

    no* aux = le_no(file, pos_atual);

    // Conta o nó atual e soma o total dos filhos esquerdo e direito
    int total = 1 + calcular_total_aux(file, aux->esq) + calcular_total_aux(file, aux->dir);

    free(aux);  // Libera a memória do nó após o uso
    return total;
}

void calcular_total(FILE* file) {
    cabecalho* cab = le_cabecalho(file);

    int total = calcular_total_aux(file, cab->pos_cabeca);

    printf("\n O número total de livros cadastrados é: %d\n", total);

    free(cab);  // Libera o cabeçalho após o uso
}

void carregar_arquivo(FILE* file_write) {
    FILE *file_read = fopen("livros.txt", "r");
    if (file_read == NULL) {
        printf("Não é possível abrir o arquivo.\n");
        return;
    }

    char line[1024];
    while (fgets(line, sizeof(line), file_read)) {
        LIVRO livro;
        char *field = NULL;

        line[strcspn(line, "\n")] = '\0';

        field = strtok(line, ";");
        livro.codigo = (field ? atoi(trim(field)) : 0);

        field = strtok(NULL, ";");
        strcpy(livro.titulo, (field ? trim(field) : ""));

        field = strtok(NULL, ";");
        strcpy(livro.autor, (field ? trim(field) : ""));

        field = strtok(NULL, ";");
        strcpy(livro.editora, (field ? trim(field) : ""));

        field = strtok(NULL, ";");
        livro.edicao = (field ? atoi(trim(field)) : 0);

        field = strtok(NULL, ";");
        livro.ano = (field ? atoi(trim(field)) : 0);

        field = strtok(NULL, ";");
        livro.preco = (field ? atof(trim(field)) : 0.0);

        field = strtok(NULL, ";");
        livro.estoque = (field ? atoi(trim(field)) : 0);

        insere_arvore(file_write, livro); // Adiciona o livro na árvore binária
    }
    printf("Arquivo .txt cadastrado com sucesso\n");

    fclose(file_read);
}
void registros_livres(FILE *file) {
    cabecalho *cab = le_cabecalho(file);
    int pos_aux = cab->pos_livre;

    if (pos_aux == -1) {
        printf("Não há registros livres para reúso.\n");
        free(cab);
        return;
    }

    printf("Posições de registros livres para reúso:\n");
    while (pos_aux != -1) {
        no *livre = le_no(file, pos_aux);

        printf("Posição livre: %d\n", pos_aux);
        pos_aux = (livre->esq != -1) ? livre->esq : livre->dir;

        free(livre);
    }

    free(cab);
}

void initQueue(Fila* q) {
    q->front = NULL;
    q->rear = NULL;
}

// Função para verificar se a fila está vazia
int isEmpty(Fila* q) {
    return (q->front == NULL);
}

// Função para adicionar um elemento à fila
void enqueue(Fila* q, int pos) {
    noFila* temp = (noFila*)malloc(sizeof(noFila));
    temp->pos = pos;
    temp->next = NULL;
    if (isEmpty(q)) {
        q->front = temp;
        q->rear = temp;
    } else {
        q->rear->next = temp;
        q->rear = temp;
    }
}

// Função para remover um elemento da fila
int dequeue(Fila* q) {
    if (isEmpty(q)) {
        return -1;
    }
    int pos = q->front->pos;
    noFila* temp = q->front;
    q->front = q->front->next;
    if (q->front == NULL) {
        q->rear = NULL;
    }
    free(temp);
    return pos;
}

// Função para imprimir a árvore binária por níveis
void imprimir_arvore_por_niveis(FILE* arq) {
    cabecalho* cab = le_cabecalho(arq);
    if (cab->pos_cabeca == -1) {
        printf("Árvore vazia.\n");
        free(cab);
        return;
    }

    Fila q;
    initQueue(&q);
    enqueue(&q, cab->pos_cabeca);

    while (!isEmpty(&q)) {
        int nivelCount = 0;
        int queueSize = 0;

        noFila* temp = q.front;
        while (temp != NULL) {
            queueSize++;
            temp = temp->next;
        }

        for (int i = 0; i < queueSize; i++) {
            int pos = dequeue(&q);
            no* atual = le_no(arq, pos);

            printf("%d ", atual->livro.codigo);
            if (atual->esq != -1) enqueue(&q, atual->esq);
            if (atual->dir != -1) enqueue(&q, atual->dir);

            free(atual);
            nivelCount++;
        }
        printf("\n");
    }

    free(cab);
}

#include <stdio.h>
#include <stdlib.h>

// Função auxiliar para imprimir a árvore formatada como lista
void imprimir_arvore_como_lista(FILE* arq, int pos) {
    if (pos == -1) {
        printf("[ ]");
        return;
    }

    no* atual = le_no(arq, pos);
    printf("[%d, ", atual->livro.codigo);

    // Imprime a subárvore esquerda
    imprimir_arvore_como_lista(arq, atual->esq);
    printf(", ");

    // Imprime a subárvore direita
    imprimir_arvore_como_lista(arq, atual->dir);
    printf("]");

    free(atual);
}

// Função principal para imprimir a árvore
void imprimir_arvore_formatada(FILE* arq) {
    cabecalho* cab = le_cabecalho(arq);
    if (cab->pos_cabeca == -1) {
        printf("Árvore vazia.\n");
    } else {
        imprimir_arvore_como_lista(arq, cab->pos_cabeca);
    }
    free(cab);
    printf("\n");
}


void menu(){
    printf("\n-----------MENU--------------\n");
    printf("Digite 1 para cadastrar um livro.\n");
    printf("Digite 2 para remover as informações de um livro.\n");
    printf("Digite 3 para imprimir dados de um livro.\n");
    printf("Digite 4 para listar todos os livros.\n");
    printf("Digite 5 para buscar livros de algum autor.\n");
    printf("Digite 6 para buscar por algum livro.\n");
    printf("Digite 7 para calcular o total de livros cadastrados.\n");
    printf("Digite 8 para carregar livros.\n");
    printf("Digite 9 para imprimir lista de registros livres.\n");
    printf("Digite 10 para listar por niveis.\n");
    printf("Digite 11 para imprimir arvore formatada como lista.\n");
    printf("Digite 0 para sair do menu.\n");
    printf("----------------------------\n");
}


