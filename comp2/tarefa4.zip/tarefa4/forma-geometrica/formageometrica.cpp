#include "forma-geometrica.h"
#include <iostream>
using namespace std;

FormaGeometrica::FormaGeometrica(){}

FormaGeometrica::~FormaGeometrica(){
    cout << "\nDestruindo forma geometrica\n";
}