#ifndef FORMAGEOMETRICA_H
#define FORMAGEOMETRICA_H

class FormaGeometrica {
    public:
        FormaGeometrica();
        virtual ~FormaGeometrica();
        virtual double getArea()= 0;
        
};

#endif